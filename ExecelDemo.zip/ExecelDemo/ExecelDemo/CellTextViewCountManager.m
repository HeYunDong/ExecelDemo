//
//  CellTextViewCountManager.m
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//

#import "CellTextViewCountManager.h"

@implementation CellTextViewCountManager

+ (CellTextViewCountManager *)sharedInstance {
    static CellTextViewCountManager *sharedInstance = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedInstance = [[CellTextViewCountManager alloc] init];
    });
    return sharedInstance;
}

@end
