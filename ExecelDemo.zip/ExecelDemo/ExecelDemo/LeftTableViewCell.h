//
//  LeftTableViewCell.h
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LeftTableViewCell;

@protocol AutoHeightTableViewCellDelegate <NSObject>

-(void)sendScanProducts:(UITableViewCell *)cell textViewIndexHeight:(CGFloat)height textViewIndex:(NSInteger)index;

@end



@interface LeftTableViewCell : UITableViewCell <UITextViewDelegate>

@property (weak, nonatomic) id <AutoHeightTableViewCellDelegate> delegate;

- (void)setData:(NSArray *)array;

@end
