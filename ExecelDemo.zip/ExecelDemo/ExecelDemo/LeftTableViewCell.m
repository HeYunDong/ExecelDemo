//
//  LeftTableViewCell.m
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//

#import "LeftTableViewCell.h"
#import "Masonry.h"
#import "CellTextViewCountManager.h"

@implementation LeftTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initCell];
    }
    return self;
}

- (void)initCell
{
//    int textViewCount = 2;
    
    UITextView * lastTextView;
    for (int i = 0; i < [CellTextViewCountManager sharedInstance].LeftTableViewCellTextViewCount; i ++) {
        UITextView * textView = [[UITextView alloc] init];
        textView.layoutManager.allowsNonContiguousLayout = NO;
        textView.delegate= self;
        [textView setScrollEnabled:NO];
        textView.tag = 100 + i;
        textView.layer.borderWidth = 0.5;
        [self.contentView addSubview:textView];
        
        [textView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView).offset(10);
            make.bottom.equalTo(self.contentView).offset(-10);
            make.width.mas_equalTo(80);
            if (lastTextView) {
                make.left.equalTo(lastTextView.mas_right);
            } else {
                make.left.equalTo(self.contentView);
            }
        }];
        
        lastTextView = textView;
        
    }
    
}

- (void)setData:(NSArray *)array {
    
    for (int i = 0; i < 2; i ++) {
        UITextView * textView = [self.contentView viewWithTag:100 + i];
        textView.text = array[i];
    }
}

-(void)textViewDidChange:(UITextView *)textView{
    
    CGSize newSize = [textView sizeThatFits:CGSizeMake(textView.frame.size.width,MAXFLOAT)];
    NSLog(@"%@",NSStringFromCGSize(newSize));
    CGFloat height = newSize.height;
    if (height < 30) {
        height = 30;
    }
    //    height += 20;
    if ([self.delegate respondsToSelector:@selector(sendScanProducts:textViewIndexHeight:textViewIndex:)]) {
        [self.delegate sendScanProducts:self textViewIndexHeight:height textViewIndex:textView.tag - 100];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
