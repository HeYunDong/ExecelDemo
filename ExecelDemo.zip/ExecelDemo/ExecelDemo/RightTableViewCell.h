//
//  RightTableViewCell.h
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftTableViewCell.h"

@interface RightTableViewCell : UITableViewCell <UITextViewDelegate>

@property (weak, nonatomic) id <AutoHeightTableViewCellDelegate> delegate;
- (void)setData:(NSArray *)array;

@end
