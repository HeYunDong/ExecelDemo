//
//  TestTableViewCell.h
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//
#import <UIKit/UIKit.h>

@class TestTableViewCell;

@protocol TestTableViewCellDelegate <NSObject>

-(void)sendScanProducts:(TestTableViewCell *)cell height:(CGFloat)height;

@end

@interface TestTableViewCell : UITableViewCell <UITextViewDelegate>

@property (weak, nonatomic) id <TestTableViewCellDelegate> delegate;

@end



