//
//  ViewController.m
//  ExecelDemo
//
//  Created by 何云东 on 2019/3/5.
//  Copyright © 2019 何云东. All rights reserved.
//


#import "ViewController.h"
//#import "TestTableViewCell.h"
#import "LeftTableViewCell.h"
#import "RightTableViewCell.h"
#import "Masonry.h"
#import "CellTextViewCountManager.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,AutoHeightTableViewCellDelegate>

@property (nonatomic, strong) UITableView * leftTableView;

@property (nonatomic, strong) UITableView * rightTableView;
@property (nonatomic, strong) UIView * rightContentView;
@property (nonatomic, strong) UIScrollView * rightScrollView;

@property (nonatomic, strong) NSMutableArray * dataSourceArray;
@property (nonatomic, strong) NSMutableArray * cellTextViewsHeightArray;
@property (nonatomic, strong) UITextView * calculateTextView;
@property (nonatomic, assign) BOOL isTouchLeftTableView;
@property (nonatomic, assign) BOOL isTouchRightTableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //    return;
    _dataSourceArray = [NSMutableArray array];
    _cellTextViewsHeightArray = [NSMutableArray array];
    
    _calculateTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, 100, 30)];
    _calculateTextView.hidden = YES;
    _calculateTextView.layoutManager.allowsNonContiguousLayout = NO;
    [_calculateTextView setScrollEnabled:NO];
    
    [_dataSourceArray setArray:@[@[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs",@"sdfqwefs"],
                                 @[@"asfwewer",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdqweqwqwe",@"sdqweqwqwe",@"sdqwedsafasfsdafafqwqwe",@"sdqweqwqwe",@"asfwewer",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdqweqwqwe",@"sdqweqwqwe",@"sdqwedsafasfsdafafqwqwe",@"sdqweqwqwe",@"asfwewer",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdqweqwqwe",@"sdqweqwqwe",@"sdqwedsafasfsdafafqwqwe",@"sdqweqwqwe"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],@[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],@[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"],
                                 @[@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs",@"asfwewer",@"ergrtgerf",@"sdfqwefs",@"sdfqwefs",@"sdfqwefsergsdfgfqefsdfqwefsergsdfgfqefsdfqwefsergsdfgfqef",@"sdfqwefs"]]];
    
    [self setHeightArray];
    
    _leftTableView = [[UITableView alloc] init];
    _leftTableView.delegate = self;
    _leftTableView.dataSource = self;
    _leftTableView.estimatedRowHeight = 50;
    _leftTableView.backgroundColor = [UIColor clearColor];
    _leftTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _leftTableView.backgroundColor = [UIColor redColor];
    _leftTableView.showsVerticalScrollIndicator = NO;
    _leftTableView.showsHorizontalScrollIndicator = NO;
    [_leftTableView registerClass:[LeftTableViewCell class] forCellReuseIdentifier:@"LeftTableViewCell"];
    
    [self.view addSubview:_leftTableView];
    
    _rightTableView = [[UITableView alloc] init];
    _rightTableView.delegate = self;
    _rightTableView.dataSource = self;
    _rightTableView.estimatedRowHeight = 50;
    _rightTableView.backgroundColor = [UIColor clearColor];
    _rightTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _rightTableView.backgroundColor = [UIColor blueColor];
    _rightTableView.showsVerticalScrollIndicator = NO;
    _rightTableView.showsHorizontalScrollIndicator = NO;
    [_rightTableView registerClass:[RightTableViewCell class] forCellReuseIdentifier:@"RightTableViewCell"];
    
    [_leftTableView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
    [_rightTableView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
    
    _rightContentView = [[UIView alloc] init];
    [_rightContentView addSubview:_rightTableView];
    
    _rightScrollView = [[UIScrollView alloc] init];
    [_rightScrollView addSubview:_rightContentView];
    
    [self.view addSubview:_rightScrollView];
    
    [_rightScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.leftTableView.mas_right);
        make.top.bottom.right.equalTo(self.view);
    }];
    
    [_rightContentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.height.equalTo(self.rightScrollView);
    }];
    
    [_leftTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(self.view);
        make.width.mas_equalTo(160);
    }];
    
    [_rightTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.bottom.height.equalTo(self.rightContentView);
        make.width.mas_equalTo(960);
    }];
    
    [_rightContentView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.rightTableView);
    }];
    
}

- (void)setHeightArray {
    [_cellTextViewsHeightArray removeAllObjects];
    for (int i = 0; i < _dataSourceArray.count; i++) {
        NSArray * rowArray = (NSArray *)_dataSourceArray[i];
        NSMutableArray * rowTextViewHeightArray = [NSMutableArray array];
        for (int j = 0; j < rowArray.count; j++) {
            NSString * text = rowArray[j];
            _calculateTextView.text = text;
            CGFloat textViewHeight = [_calculateTextView sizeThatFits:CGSizeMake(80,MAXFLOAT)].height;
            [rowTextViewHeightArray addObject:@(textViewHeight)];
        }
        [_cellTextViewsHeightArray addObject:rowTextViewHeightArray];
    }
}

- (CGFloat)getMaxHeightWithRow:(NSInteger)row {
    CGFloat maxHeight = 0;
    NSArray * array = _cellTextViewsHeightArray[row];
    for (int i = 0; i < array.count; i ++) {
        CGFloat height = [(NSNumber *)array[i] floatValue];
        if (height > maxHeight) {
            maxHeight = height;
        }
    }
    return maxHeight;
}

#pragma mark ======================================
#pragma mark ===<UITableViewDataSource>
#pragma mark ======================================
//组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
//每组的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataSourceArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [CellTextViewCountManager sharedInstance].LeftTableViewCellTextViewCount = 2;
    if (tableView == _leftTableView) {
        LeftTableViewCell * cell =  [tableView dequeueReusableCellWithIdentifier:@"LeftTableViewCell" forIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        cell.delegate = self;
        [cell setData:_dataSourceArray[indexPath.row]];
        return cell;
    } else {
        RightTableViewCell * cell =  [tableView dequeueReusableCellWithIdentifier:@"RightTableViewCell" forIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        cell.delegate = self;
        [cell setData:_dataSourceArray[indexPath.row]];
        return cell;
    }
}

#pragma mark ======================================
#pragma mark ===<UITableViewDelegate>
#pragma mark ======================================
//点击单元格时
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

//单元格高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = [self getMaxHeightWithRow:indexPath.row]+20;
    if (height < 50) {
        height = 50;
    }
    return height;
}

- (void)sendScanProducts:(UITableViewCell *)cell textViewIndexHeight:(CGFloat)height textViewIndex:(NSInteger)index {
    
    if ([cell isMemberOfClass:[LeftTableViewCell class]]) {
        _cellTextViewsHeightArray[[_leftTableView indexPathForCell:cell].row][index] = @(height);
    } else {
        _cellTextViewsHeightArray[[_rightTableView indexPathForCell:cell].row][index+2] = @(height);
    }
    
    [_leftTableView beginUpdates];
    [_rightTableView beginUpdates];
    
    [_leftTableView endUpdates];
    [_rightTableView endUpdates];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if (object == _leftTableView) {
        _isTouchLeftTableView = YES;
        if (_isTouchRightTableView) {
            return;
        }
        [_rightTableView setContentOffset:CGPointMake(_rightTableView.contentOffset.x,_leftTableView.contentOffset.y)];
    } else {
        _isTouchRightTableView = YES;
        if (_isTouchLeftTableView) {
            return;
        }
        [_leftTableView setContentOffset:CGPointMake(_leftTableView.contentOffset.x,_rightTableView.contentOffset.y)];
    }
    _isTouchLeftTableView = NO;
    _isTouchRightTableView = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
